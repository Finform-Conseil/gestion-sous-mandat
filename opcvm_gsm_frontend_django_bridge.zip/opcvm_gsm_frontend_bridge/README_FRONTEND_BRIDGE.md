# Bridge progressif React -> Django

Copier :

```text
src/api/gsmBackend.js
```

dans le projet Vite, puis remplacer `src/App.jsx` par la version fournie.

Créer `.env.local` :

```env
VITE_GSM_DJANGO_API_URL=http://127.0.0.1:8001/api/v1
VITE_GSM_DEMO_USER=admin.sgi
VITE_GSM_DEMO_PASSWORD=Demo1234!
```

Les identifiants `VITE_GSM_DEMO_*` sont uniquement prévus pour le poste de développement.
En production, l'écran de connexion doit appeler `/api/v1/auth/token/`.

## Comportement

Au chargement :

1. le frontend tente Django `/compat/bootstrap/`;
2. si Django répond :
   - `Mes portefeuilles & SGI` reçoit `freePortfolios`;
   - Gestion sous mandat reçoit `managedClients`;
   - Rapport de comité reçoit `committeeDecisions`;
3. si Django est indisponible, l'application garde exactement son fallback actuel :
   ancienne API opérationnelle puis données locales.

Cette stratégie permet de migrer écran par écran.
