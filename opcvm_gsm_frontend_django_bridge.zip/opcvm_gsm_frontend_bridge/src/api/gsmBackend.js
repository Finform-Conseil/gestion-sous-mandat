const GSM_DJANGO_API_ROOT =
  import.meta?.env?.VITE_GSM_DJANGO_API_URL ||
  'http://127.0.0.1:8001/api/v1';

const ACCESS_KEY = 'opcvm-gsm-django-access-token';
const REFRESH_KEY = 'opcvm-gsm-django-refresh-token';
const INSTITUTION_KEY = 'opcvm-gsm-django-institution-id';

const apiUrl = (path = '') =>
  `${GSM_DJANGO_API_ROOT}${path.startsWith('/') ? path : `/${path}`}`;

const storageGet = (key) => {
  if (typeof window === 'undefined') return '';
  return window.sessionStorage.getItem(key) || '';
};

const storageSet = (key, value) => {
  if (typeof window === 'undefined') return;
  if (value) window.sessionStorage.setItem(key, value);
  else window.sessionStorage.removeItem(key);
};

const requestRaw = async (
  path,
  { method = 'GET', body = null, accessToken = '', institutionId = '' } = {}
) => {
  const headers = { Accept: 'application/json' };
  if (body !== null) headers['Content-Type'] = 'application/json';
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
  if (institutionId) headers['X-Institution-ID'] = institutionId;

  const response = await fetch(apiUrl(path), {
    method,
    headers,
    body: body === null ? undefined : JSON.stringify(body),
    cache: 'no-store',
  });

  const raw = await response.text();
  let payload = null;
  try {
    payload = raw ? JSON.parse(raw) : null;
  } catch {
    payload = raw;
  }

  if (!response.ok) {
    const error = new Error(
      payload?.detail ||
      (typeof payload === 'string' ? payload : `HTTP ${response.status}`)
    );
    error.status = response.status;
    error.payload = payload;
    throw error;
  }

  return payload;
};

const refreshAccessToken = async () => {
  const refresh = storageGet(REFRESH_KEY);
  if (!refresh) return '';

  try {
    const payload = await requestRaw('/auth/token/refresh/', {
      method: 'POST',
      body: { refresh },
    });
    storageSet(ACCESS_KEY, payload?.access || '');
    return payload?.access || '';
  } catch {
    storageSet(ACCESS_KEY, '');
    storageSet(REFRESH_KEY, '');
    return '';
  }
};

export const gsmDjangoLogin = async (username, password) => {
  const payload = await requestRaw('/auth/token/', {
    method: 'POST',
    body: { username, password },
  });

  storageSet(ACCESS_KEY, payload?.access || '');
  storageSet(REFRESH_KEY, payload?.refresh || '');
  return payload;
};

export const gsmDjangoLogout = () => {
  storageSet(ACCESS_KEY, '');
  storageSet(REFRESH_KEY, '');
  storageSet(INSTITUTION_KEY, '');
};

export const gsmDjangoRequest = async (
  path,
  { method = 'GET', body = null, institutionId = null } = {}
) => {
  let accessToken = storageGet(ACCESS_KEY);

  if (!accessToken) {
    const demoUser = import.meta?.env?.VITE_GSM_DEMO_USER || '';
    const demoPassword = import.meta?.env?.VITE_GSM_DEMO_PASSWORD || '';

    if (demoUser && demoPassword) {
      await gsmDjangoLogin(demoUser, demoPassword);
      accessToken = storageGet(ACCESS_KEY);
    }
  }

  if (!accessToken) {
    throw new Error(
      'Aucun token Django. Connectez-vous ou définissez les identifiants démo en environnement local.'
    );
  }

  let tenant = institutionId || storageGet(INSTITUTION_KEY);

  if (!tenant && !path.startsWith('/institutions')) {
    const institutions = await gsmDjangoRequest('/institutions/');
    const first =
      Array.isArray(institutions)
        ? institutions[0]
        : institutions?.results?.[0];

    if (!first?.id) {
      throw new Error("Aucune SGI accessible pour l'utilisateur connecté.");
    }

    tenant = String(first.id);
    storageSet(INSTITUTION_KEY, tenant);
  }

  try {
    return await requestRaw(path, {
      method,
      body,
      accessToken,
      institutionId: tenant || '',
    });
  } catch (error) {
    if (error.status !== 401) throw error;

    const refreshed = await refreshAccessToken();
    if (!refreshed) throw error;

    return requestRaw(path, {
      method,
      body,
      accessToken: refreshed,
      institutionId: tenant || '',
    });
  }
};

export const loadGsmDjangoBootstrap = async () => {
  return gsmDjangoRequest('/compat/bootstrap/');
};

export const listGsmInstitutions = async () => {
  return gsmDjangoRequest('/institutions/');
};

export const setGsmActiveInstitution = (institutionId) => {
  storageSet(INSTITUTION_KEY, institutionId || '');
};

export const getGsmActiveInstitution = () => storageGet(INSTITUTION_KEY);
