$ErrorActionPreference = "Stop"
& ".\.venv\Scripts\Activate.ps1"

if (Get-Command docker -ErrorAction SilentlyContinue) {
    docker compose up -d postgres redis
    $env:DB_ENGINE = "postgres"
    $env:DB_NAME = "opcvm_gsm"
    $env:DB_USER = "opcvm_gsm"
    $env:DB_PASSWORD = "opcvm_gsm_dev"
    $env:DB_HOST = "127.0.0.1"
    $env:DB_PORT = "5432"
}

python manage.py runserver 8001
