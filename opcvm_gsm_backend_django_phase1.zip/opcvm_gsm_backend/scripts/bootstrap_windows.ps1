$ErrorActionPreference = "Stop"

Write-Host "=== OPCVM GSM | Bootstrap Django/PostgreSQL ===" -ForegroundColor Cyan

if (-not (Test-Path ".venv")) {
    python -m venv .venv
}

& ".\.venv\Scripts\Activate.ps1"

python -m pip install --upgrade pip
pip install -r requirements.txt

if (Get-Command docker -ErrorAction SilentlyContinue) {
    Write-Host "Démarrage PostgreSQL + Redis..." -ForegroundColor Cyan
    docker compose up -d postgres redis
    Start-Sleep -Seconds 4

    $env:DB_ENGINE = "postgres"
    $env:DB_NAME = "opcvm_gsm"
    $env:DB_USER = "opcvm_gsm"
    $env:DB_PASSWORD = "opcvm_gsm_dev"
    $env:DB_HOST = "127.0.0.1"
    $env:DB_PORT = "5432"
} else {
    Write-Warning "Docker absent : Django utilisera SQLite pour le test local."
    $env:DB_ENGINE = "sqlite"
}

Write-Host "Création des premières migrations..." -ForegroundColor Cyan
python manage.py makemigrations accounts institutions instruments clients portfolios ledger orders committees imports marketdata

Write-Host "Application des migrations..." -ForegroundColor Cyan
python manage.py migrate

Write-Host "Création de la SGI de test..." -ForegroundColor Cyan
python manage.py seed_demo

Write-Host ""
Write-Host "Backend prêt." -ForegroundColor Green
Write-Host "Login démo : admin.sgi / Demo1234!"
Write-Host "Lancez ensuite : python manage.py runserver 8001"
