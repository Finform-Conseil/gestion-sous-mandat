$ErrorActionPreference = "Stop"

$Base = "http://127.0.0.1:8001/api/v1"

Write-Host "Authentification..." -ForegroundColor Cyan
$token = Invoke-RestMethod `
  -Uri "$Base/auth/token/" `
  -Method Post `
  -ContentType "application/json" `
  -Body (@{
      username = "admin.sgi"
      password = "Demo1234!"
    } | ConvertTo-Json)

$headers = @{
  Authorization = "Bearer $($token.access)"
}

Write-Host "Lecture des institutions..." -ForegroundColor Cyan
$institutions = Invoke-RestMethod `
  -Uri "$Base/institutions/" `
  -Headers $headers `
  -Method Get

$items = if ($institutions.results) { $institutions.results } else { $institutions }

if (-not $items -or $items.Count -eq 0) {
  throw "Aucune institution trouvée."
}

$institutionId = $items[0].id
$headers["X-Institution-ID"] = $institutionId

Write-Host "Institution : $($items[0].legal_name) | $institutionId" -ForegroundColor Green

Write-Host "Test bootstrap de compatibilité..." -ForegroundColor Cyan
$bootstrap = Invoke-RestMethod `
  -Uri "$Base/compat/bootstrap/" `
  -Headers $headers `
  -Method Get

Write-Host ""
Write-Host "Résultat :" -ForegroundColor Green
Write-Host "  Portefeuilles Gestion libre : $($bootstrap.freePortfolios.Count)"
Write-Host "  Portefeuilles Gestion sous mandat : $($bootstrap.managedClients.Count)"
Write-Host "  Rapports/décisions comité : $($bootstrap.committeeDecisions.Count)"

$bootstrap | ConvertTo-Json -Depth 8 | Out-File -Encoding utf8 "bootstrap_api_result.json"
Write-Host "Réponse complète écrite dans bootstrap_api_result.json"
