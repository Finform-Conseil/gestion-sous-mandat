# Premières migrations

Le bootstrap Windows génère les migrations à partir des modèles réellement présents :

```powershell
python manage.py makemigrations accounts institutions instruments clients portfolios ledger orders committees imports marketdata
python manage.py migrate
```

Ordre logique des dépendances :

1. `accounts`
2. `institutions`
3. `instruments`
4. `clients`
5. `portfolios`
6. `ledger`
7. `orders`
8. `committees`
9. `imports`
10. `marketdata`

Il est volontairement préférable de laisser Django écrire les fichiers `0001_initial.py`
sur la machine qui possède les dépendances Django installées. Cela garantit que les
dépendances `AUTH_USER_MODEL`, les contraintes, les indexes et les relations M2M
sont générés par la version réelle de Django utilisée par le projet.

Après génération :

```powershell
git add apps/*/migrations
git commit -m "Initial Django schema for OPCVM GSM"
```

Puis ne jamais supprimer ou régénérer les migrations déjà appliquées en production :
les évolutions suivantes doivent produire `0002_...`, `0003_...`, etc.
