# Architecture métier

## Source de vérité

Les mouvements sont la source historique :

- `SecurityMovement`
- `CashMovement`

Les états calculés servent à l'affichage :

- `PositionSnapshot`
- `CashBalanceSnapshot`
- `ValuationSnapshot`

## Gestion libre

Un portefeuille externe peut être représenté par :

```text
Portfolio.management_mode = FREE
SecuritiesAccount.is_external = True
SecuritiesAccount.custodian_name = nom de la SGI externe
```

Le client importe ses données via `ImportJob`.

## Gestion sous mandat

```text
Portfolio.management_mode = MANDATED
PortfolioAssignment -> Gestionnaire
Mandate -> contrat de gestion
```

## Ordres

```text
Order
 -> OrderEvent
 -> Execution
 -> Allocation
```

Le workflow Client -> Chargé clientèle -> Négociateur est géré par
`Order.status` + `OrderEvent`.

## Comité

```text
CommitteeSession
 -> CommitteeDecision
    -> DecisionTarget
    -> DecisionExecution
    -> DecisionDeviation
```

Le frame "Résultat des récentes décisions d'investissement" pourra être calculé
directement depuis ces quatre tables et les cours de `MarketPrice`.
