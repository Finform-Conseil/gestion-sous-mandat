from django.db import models
from apps.core.models import UUIDModel, TimeStampedModel

class MarketIndex(UUIDModel, TimeStampedModel):
    exchange = models.ForeignKey("instruments.Exchange", on_delete=models.PROTECT, related_name="indices")
    code = models.CharField(max_length=64)
    name = models.CharField(max_length=255)
    currency = models.CharField(max_length=8)
    is_active = models.BooleanField(default=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["exchange", "code"], name="uq_market_index_exchange_code")
        ]

class IndexLevel(UUIDModel, TimeStampedModel):
    index = models.ForeignKey(MarketIndex, on_delete=models.CASCADE, related_name="levels")
    date = models.DateField()
    open = models.DecimalField(max_digits=28, decimal_places=8, null=True, blank=True)
    high = models.DecimalField(max_digits=28, decimal_places=8, null=True, blank=True)
    low = models.DecimalField(max_digits=28, decimal_places=8, null=True, blank=True)
    close = models.DecimalField(max_digits=28, decimal_places=8)
    source = models.CharField(max_length=120)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["index", "date", "source"],
                name="uq_index_level_date_source",
            )
        ]
        indexes = [models.Index(fields=["index", "date"])]

class MarketPrice(UUIDModel, TimeStampedModel):
    instrument = models.ForeignKey("instruments.Instrument", on_delete=models.CASCADE, related_name="prices")
    date = models.DateField()
    close = models.DecimalField(max_digits=28, decimal_places=8)
    open = models.DecimalField(max_digits=28, decimal_places=8, null=True, blank=True)
    high = models.DecimalField(max_digits=28, decimal_places=8, null=True, blank=True)
    low = models.DecimalField(max_digits=28, decimal_places=8, null=True, blank=True)
    volume = models.DecimalField(max_digits=28, decimal_places=8, null=True, blank=True)
    currency = models.CharField(max_length=8)
    source = models.CharField(max_length=120)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["instrument", "date", "source"],
                name="uq_market_price_date_source",
            )
        ]

class FXRate(UUIDModel, TimeStampedModel):
    base_currency = models.CharField(max_length=8)
    quote_currency = models.CharField(max_length=8)
    date = models.DateField()
    rate = models.DecimalField(max_digits=28, decimal_places=12)
    source = models.CharField(max_length=120)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["base_currency", "quote_currency", "date", "source"],
                name="uq_fx_rate",
            )
        ]
