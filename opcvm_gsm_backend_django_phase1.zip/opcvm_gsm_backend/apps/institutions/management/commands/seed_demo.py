from datetime import date, datetime
from decimal import Decimal

from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone

from apps.accounts.models import User
from apps.institutions.models import Institution, InstitutionMembership
from apps.instruments.models import Exchange, Issuer, Instrument
from apps.clients.models import Client, Mandate
from apps.portfolios.models import (
    Portfolio, PortfolioAssignment, SecuritiesAccount, CashAccount,
)
from apps.ledger.models import (
    PositionSnapshot, CashBalanceSnapshot, ValuationSnapshot,
)
from apps.committees.models import (
    CommitteeSession, CommitteeDecision, DecisionTarget, DecisionExecution,
)


AS_OF = date(2026, 11, 4)


class Command(BaseCommand):
    help = "Crée une SGI de test et un petit jeu de données pour brancher le frontend."

    @transaction.atomic
    def handle(self, *args, **options):
        sgi, _ = Institution.objects.update_or_create(
            code="SGI-DEMO",
            defaults={
                "legal_name": "Atlantic Bourse — Environnement Démo",
                "country": "Côte d'Ivoire",
                "base_currency": "XOF",
                "is_active": True,
            },
        )

        admin, created = User.objects.get_or_create(
            username="admin.sgi",
            defaults={
                "email": "admin.sgi@example.local",
                "first_name": "Admin",
                "last_name": "SGI",
            },
        )
        if created or not admin.has_usable_password():
            admin.set_password("Demo1234!")
            admin.save(update_fields=["password"])

        manager, created = User.objects.get_or_create(
            username="gestionnaire.demo",
            defaults={
                "email": "gestionnaire.demo@example.local",
                "first_name": "Awa",
                "last_name": "Koné",
            },
        )
        if created or not manager.has_usable_password():
            manager.set_password("Demo1234!")
            manager.save(update_fields=["password"])

        InstitutionMembership.objects.update_or_create(
            institution=sgi,
            user=admin,
            role=InstitutionMembership.Role.ADMIN,
            defaults={"is_active": True},
        )
        InstitutionMembership.objects.update_or_create(
            institution=sgi,
            user=manager,
            role=InstitutionMembership.Role.PORTFOLIO_MANAGER,
            defaults={"is_active": True},
        )

        brvm, _ = Exchange.objects.update_or_create(
            code="BRVM",
            defaults={
                "name": "Bourse Régionale des Valeurs Mobilières",
                "country": "UEMOA",
                "currency": "XOF",
            },
        )
        ngx, _ = Exchange.objects.update_or_create(
            code="NGX",
            defaults={
                "name": "Nigerian Exchange",
                "country": "Nigeria",
                "currency": "NGN",
            },
        )

        sonatel_issuer, _ = Issuer.objects.get_or_create(
            name="SONATEL",
            defaults={"country": "Sénégal", "sector": "Télécommunications"},
        )
        ecobank_issuer, _ = Issuer.objects.get_or_create(
            name="ECOBANK Côte d'Ivoire",
            defaults={"country": "Côte d'Ivoire", "sector": "Banques"},
        )
        ci_issuer, _ = Issuer.objects.get_or_create(
            name="État de Côte d'Ivoire",
            defaults={"country": "Côte d'Ivoire", "sector": "Souverain"},
        )
        zenith_issuer, _ = Issuer.objects.get_or_create(
            name="Zenith Bank",
            defaults={"country": "Nigeria", "sector": "Banques"},
        )

        sonatel, _ = Instrument.objects.update_or_create(
            exchange=brvm,
            symbol="SONATEL",
            defaults={
                "name": "SONATEL",
                "isin": "SN0000000019",
                "asset_class": Instrument.AssetClass.LISTED_EQUITY,
                "issuer": sonatel_issuer,
                "currency": "XOF",
                "is_active": True,
            },
        )
        ecobank, _ = Instrument.objects.update_or_create(
            exchange=brvm,
            symbol="ECOBANK-CI",
            defaults={
                "name": "ECOBANK CI",
                "asset_class": Instrument.AssetClass.LISTED_EQUITY,
                "issuer": ecobank_issuer,
                "currency": "XOF",
                "is_active": True,
            },
        )
        oat_ci, _ = Instrument.objects.update_or_create(
            exchange=brvm,
            symbol="OAT-CI-2029",
            defaults={
                "name": "Obligation Trésor CI 6.5% 2029",
                "asset_class": Instrument.AssetClass.LISTED_BOND,
                "issuer": ci_issuer,
                "currency": "XOF",
                "is_active": True,
            },
        )
        zenith, _ = Instrument.objects.update_or_create(
            exchange=ngx,
            symbol="ZENITHBANK",
            defaults={
                "name": "ZENITH BANK",
                "asset_class": Instrument.AssetClass.LISTED_EQUITY,
                "issuer": zenith_issuer,
                "currency": "NGN",
                "is_active": True,
            },
        )

        # ---------------- Gestion libre : compte externe SGI ----------------
        free_client, _ = Client.objects.update_or_create(
            institution=sgi,
            external_id="FREE-KORA-001",
            defaults={
                "client_type": Client.ClientType.INSTITUTIONAL,
                "display_name": "Groupe Kora Holdings SA",
                "legal_name": "Groupe Kora Holdings SA",
                "country": "Côte d'Ivoire",
                "status": "ACTIVE",
            },
        )
        free_mandate, _ = Mandate.objects.update_or_create(
            institution=sgi,
            reference="GL-KORA-001",
            defaults={
                "client": free_client,
                "mandate_type": Mandate.MandateType.FREE,
                "start_date": date(2024, 1, 15),
                "status": "ACTIVE",
            },
        )
        free_pf, _ = Portfolio.objects.update_or_create(
            institution=sgi,
            code="PF-GL-KORA-BRVM",
            defaults={
                "client": free_client,
                "mandate": free_mandate,
                "name": "Groupe Kora Holdings SA · Réserve stratégique Côte d’Ivoire",
                "management_mode": Portfolio.ManagementMode.FREE,
                "base_currency": "XOF",
                "risk_profile": "Équilibré",
                "status": "ACTIVE",
            },
        )
        sec_acc, _ = SecuritiesAccount.objects.update_or_create(
            institution=sgi,
            portfolio=free_pf,
            account_number="CT-0014582",
            custodian_name="Atlantic Bourse",
            defaults={
                "market": "BRVM",
                "currency": "XOF",
                "opened_at": date(2024, 1, 15),
                "is_external": True,
            },
        )
        cash_acc, _ = CashAccount.objects.update_or_create(
            institution=sgi,
            portfolio=free_pf,
            account_number="CASH-0014582",
            defaults={
                "currency": "XOF",
                "bank_or_custodian": "Atlantic Bourse",
                "is_primary": True,
            },
        )

        free_positions = [
            (sonatel, "4200", "13250", "14200"),
            (ecobank, "3000", "6920", "6650"),
            (oat_ci, "3500", "10010", "10050"),
        ]
        securities_value = Decimal("0")
        for instrument, qty, pru, px in free_positions:
            q = Decimal(qty)
            p = Decimal(px)
            securities_value += q * p
            PositionSnapshot.objects.update_or_create(
                institution=sgi,
                portfolio=free_pf,
                instrument=instrument,
                as_of=AS_OF,
                defaults={
                    "quantity": q,
                    "available_quantity": q,
                    "blocked_quantity": Decimal("0"),
                    "average_cost": Decimal(pru),
                    "market_price": p,
                    "market_value": q * p,
                    "accrued_income": Decimal("0"),
                    "currency": instrument.currency,
                },
            )

        CashBalanceSnapshot.objects.update_or_create(
            institution=sgi,
            portfolio=free_pf,
            cash_account=cash_acc,
            as_of=AS_OF,
            defaults={
                "available": Decimal("12885000"),
                "reserved": Decimal("2115000"),
                "total": Decimal("15000000"),
                "currency": "XOF",
            },
        )
        ValuationSnapshot.objects.update_or_create(
            institution=sgi,
            portfolio=free_pf,
            as_of=AS_OF,
            defaults={
                "securities_value": securities_value,
                "cash_value": Decimal("15000000"),
                "accrued_income": Decimal("750000"),
                "total_value": securities_value + Decimal("15750000"),
                "external_flow_net": Decimal("0"),
                "daily_return": Decimal("0.0018"),
                "ytd_return": Decimal("6.40"),
                "currency": "XOF",
            },
        )

        # ---------------- Gestion sous mandat ----------------
        managed_specs = [
            {
                "external": "MAND-AICHA",
                "name": "Aïcha Koné",
                "type": Client.ClientType.INDIVIDUAL,
                "country": "Côte d'Ivoire",
                "code": "PF-GSM-AICHA",
                "encours": Decimal("245000000"),
                "cash": Decimal("29400000"),
                "sonatel_qty": Decimal("7000"),
                "oat_qty": Decimal("8500"),
            },
            {
                "external": "MAND-FPCI",
                "name": "Fonds Prévoyance CI",
                "type": Client.ClientType.INSTITUTIONAL,
                "country": "Côte d'Ivoire",
                "code": "PF-GSM-FPCI",
                "encours": Decimal("1850000000"),
                "cash": Decimal("185000000"),
                "sonatel_qty": Decimal("12000"),
                "oat_qty": Decimal("90000"),
            },
            {
                "external": "MAND-GAS",
                "name": "Groupe Assurance Sahel",
                "type": Client.ClientType.INSTITUTIONAL,
                "country": "Sénégal",
                "code": "PF-GSM-GAS",
                "encours": Decimal("780000000"),
                "cash": Decimal("93600000"),
                "sonatel_qty": Decimal("18000"),
                "oat_qty": Decimal("28000"),
            },
        ]

        managed_portfolios = []
        for spec in managed_specs:
            client, _ = Client.objects.update_or_create(
                institution=sgi,
                external_id=spec["external"],
                defaults={
                    "client_type": spec["type"],
                    "display_name": spec["name"],
                    "legal_name": spec["name"],
                    "country": spec["country"],
                    "status": "ACTIVE",
                },
            )
            mandate, _ = Mandate.objects.update_or_create(
                institution=sgi,
                reference=f"MANDATE-{spec['code']}",
                defaults={
                    "client": client,
                    "mandate_type": Mandate.MandateType.DISCRETIONARY,
                    "start_date": date(2024, 1, 1),
                    "status": "ACTIVE",
                },
            )
            pf, _ = Portfolio.objects.update_or_create(
                institution=sgi,
                code=spec["code"],
                defaults={
                    "client": client,
                    "mandate": mandate,
                    "name": spec["name"],
                    "management_mode": Portfolio.ManagementMode.MANDATED,
                    "base_currency": "XOF",
                    "risk_profile": "Équilibré",
                    "status": "ACTIVE",
                },
            )
            PortfolioAssignment.objects.update_or_create(
                institution=sgi,
                portfolio=pf,
                user=manager,
                role="PORTFOLIO_MANAGER",
                defaults={
                    "valid_from": date(2024, 1, 1),
                    "is_primary": True,
                },
            )
            sa, _ = SecuritiesAccount.objects.update_or_create(
                institution=sgi,
                portfolio=pf,
                account_number=f"CT-{spec['code']}",
                custodian_name=sgi.legal_name,
                defaults={"market": "BRVM", "currency": "XOF", "is_external": False},
            )
            ca, _ = CashAccount.objects.update_or_create(
                institution=sgi,
                portfolio=pf,
                account_number=f"CASH-{spec['code']}",
                defaults={"currency": "XOF", "bank_or_custodian": sgi.legal_name, "is_primary": True},
            )

            PositionSnapshot.objects.update_or_create(
                institution=sgi, portfolio=pf, instrument=sonatel, as_of=AS_OF,
                defaults={
                    "quantity": spec["sonatel_qty"],
                    "available_quantity": spec["sonatel_qty"],
                    "blocked_quantity": 0,
                    "average_cost": 13200,
                    "market_price": 14200,
                    "market_value": spec["sonatel_qty"] * Decimal("14200"),
                    "accrued_income": 0,
                    "currency": "XOF",
                },
            )
            PositionSnapshot.objects.update_or_create(
                institution=sgi, portfolio=pf, instrument=oat_ci, as_of=AS_OF,
                defaults={
                    "quantity": spec["oat_qty"],
                    "available_quantity": spec["oat_qty"],
                    "blocked_quantity": 0,
                    "average_cost": 10000,
                    "market_price": 10050,
                    "market_value": spec["oat_qty"] * Decimal("10050"),
                    "accrued_income": 0,
                    "currency": "XOF",
                },
            )
            CashBalanceSnapshot.objects.update_or_create(
                institution=sgi, portfolio=pf, cash_account=ca, as_of=AS_OF,
                defaults={
                    "available": spec["cash"],
                    "reserved": 0,
                    "total": spec["cash"],
                    "currency": "XOF",
                },
            )
            ValuationSnapshot.objects.update_or_create(
                institution=sgi, portfolio=pf, as_of=AS_OF,
                defaults={
                    "securities_value": spec["encours"] - spec["cash"],
                    "cash_value": spec["cash"],
                    "accrued_income": 0,
                    "total_value": spec["encours"],
                    "external_flow_net": 0,
                    "daily_return": Decimal("0.0010"),
                    "ytd_return": Decimal("3.20"),
                    "currency": "XOF",
                },
            )
            managed_portfolios.append(pf)

        # ---------------- Rapport de comité ----------------
        committee, _ = CommitteeSession.objects.update_or_create(
            institution=sgi,
            title="Comité d'investissement — 7 octobre 2026",
            defaults={
                "meeting_date": timezone.make_aware(datetime(2026, 10, 7, 9, 0)),
                "status": "VALIDATED",
                "chairman": manager,
                "minutes_summary": "Renforcement SONATEL et obligations souveraines CI.",
                "validated_at": timezone.make_aware(datetime(2026, 10, 7, 12, 5)),
            },
        )
        committee.participants.set([manager, admin])

        decision1, _ = CommitteeDecision.objects.update_or_create(
            institution=sgi,
            session=committee,
            instrument=sonatel,
            side="BUY",
            defaults={
                "market": "BRVM",
                "portfolio_type": "Tous",
                "allocation_percentage": Decimal("35"),
                "min_price": Decimal("13200"),
                "max_price": Decimal("14000"),
                "target_price": Decimal("15000"),
                "order_type": "LIMIT",
                "rationale": "Renforcement après amélioration des perspectives bénéficiaires.",
            },
        )
        decision2, _ = CommitteeDecision.objects.update_or_create(
            institution=sgi,
            session=committee,
            instrument=oat_ci,
            side="BUY",
            defaults={
                "market": "BRVM",
                "portfolio_type": "Tous",
                "allocation_percentage": Decimal("45"),
                "min_price": Decimal("9950"),
                "max_price": Decimal("10040"),
                "target_price": Decimal("10150"),
                "order_type": "LIMIT",
                "rationale": "Renforcement de la poche souveraine et sécurisation du rendement.",
            },
        )

        for pf in managed_portfolios:
            for dec, pct in [(decision1, Decimal("35")), (decision2, Decimal("45"))]:
                target, _ = DecisionTarget.objects.update_or_create(
                    institution=sgi,
                    decision=dec,
                    portfolio=pf,
                    defaults={
                        "recommended_amount": Decimal("25000000") * pct / Decimal("100"),
                        "recommended_quantity": None,
                        "currency": "XOF",
                    },
                )
                DecisionExecution.objects.update_or_create(
                    institution=sgi,
                    decision=dec,
                    portfolio=pf,
                    manager=manager,
                    defaults={
                        "executed_amount": target.recommended_amount * Decimal("0.90"),
                        "executed_quantity": Decimal("0"),
                        "average_execution_price": dec.max_price,
                        "current_mark_price": (
                            Decimal("14200") if dec.instrument_id == sonatel.id
                            else Decimal("10050")
                        ),
                        "result_percentage": (
                            Decimal("1.43") if dec.instrument_id == sonatel.id
                            else Decimal("0.10")
                        ),
                        "as_of": timezone.now(),
                    },
                )

        self.stdout.write(self.style.SUCCESS(
            "Seed terminé. Login test: admin.sgi / Demo1234! | "
            f"Institution: {sgi.id}"
        ))
