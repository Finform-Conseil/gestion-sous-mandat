from django.conf import settings
from django.db import models
from apps.core.models import UUIDModel, TimeStampedModel

class Institution(UUIDModel, TimeStampedModel):
    code = models.CharField(max_length=32, unique=True)
    legal_name = models.CharField(max_length=255)
    country = models.CharField(max_length=80)
    base_currency = models.CharField(max_length=8, default="XOF")
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.code} — {self.legal_name}"

class InstitutionMembership(UUIDModel, TimeStampedModel):
    class Role(models.TextChoices):
        ADMIN = "ADMIN_SGI", "Administrateur SGI"
        HEAD_PM = "HEAD_PM", "Responsable gestion"
        PORTFOLIO_MANAGER = "PORTFOLIO_MANAGER", "Gestionnaire"
        CUSTOMER_OFFICER = "CUSTOMER_OFFICER", "Chargé de clientèle"
        TRADER = "TRADER", "Négociateur"
        BACK_OFFICE = "BACK_OFFICE", "Back-office"
        COMPLIANCE = "COMPLIANCE", "Conformité"
        AUDITOR = "AUDITOR", "Auditeur"
        CLIENT = "CLIENT", "Client"

    institution = models.ForeignKey(Institution, on_delete=models.CASCADE, related_name="memberships")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="memberships")
    role = models.CharField(max_length=32, choices=Role.choices)
    is_active = models.BooleanField(default=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["institution", "user", "role"],
                name="uq_membership_institution_user_role",
            )
        ]
