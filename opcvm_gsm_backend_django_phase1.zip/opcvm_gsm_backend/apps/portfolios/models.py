from django.conf import settings
from django.db import models
from apps.core.models import InstitutionOwnedModel

class Portfolio(InstitutionOwnedModel):
    class ManagementMode(models.TextChoices):
        MANDATED = "MANDATED", "Gestion sous mandat"
        FREE = "FREE", "Gestion libre"

    client = models.ForeignKey("clients.Client", on_delete=models.PROTECT, related_name="portfolios")
    mandate = models.ForeignKey(
        "clients.Mandate", on_delete=models.SET_NULL, null=True, blank=True, related_name="portfolios"
    )
    code = models.CharField(max_length=80)
    name = models.CharField(max_length=255)
    management_mode = models.CharField(max_length=16, choices=ManagementMode.choices)
    base_currency = models.CharField(max_length=8)
    risk_profile = models.CharField(max_length=64, blank=True)
    status = models.CharField(max_length=24, default="ACTIVE")
    investment_constraints = models.JSONField(default=dict, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["institution", "code"],
                name="uq_portfolio_institution_code",
            )
        ]

class PortfolioAssignment(InstitutionOwnedModel):
    portfolio = models.ForeignKey(Portfolio, on_delete=models.CASCADE, related_name="assignments")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    role = models.CharField(max_length=32, default="PORTFOLIO_MANAGER")
    valid_from = models.DateField()
    valid_to = models.DateField(null=True, blank=True)
    is_primary = models.BooleanField(default=False)

class SecuritiesAccount(InstitutionOwnedModel):
    portfolio = models.ForeignKey(Portfolio, on_delete=models.CASCADE, related_name="securities_accounts")
    account_number = models.CharField(max_length=120)
    custodian_institution = models.ForeignKey(
        "institutions.Institution",
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="custodied_securities_accounts",
    )
    custodian_name = models.CharField(max_length=255, blank=True)
    market = models.CharField(max_length=32, blank=True)
    currency = models.CharField(max_length=8)
    opened_at = models.DateField(null=True, blank=True)
    is_external = models.BooleanField(default=False)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["institution", "account_number", "custodian_name"],
                name="uq_securities_account_tenant_number_custodian",
            )
        ]

class CashAccount(InstitutionOwnedModel):
    portfolio = models.ForeignKey(Portfolio, on_delete=models.CASCADE, related_name="cash_accounts")
    account_number = models.CharField(max_length=120)
    currency = models.CharField(max_length=8)
    bank_or_custodian = models.CharField(max_length=255, blank=True)
    is_primary = models.BooleanField(default=False)
