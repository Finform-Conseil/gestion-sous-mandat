from django.db import transaction
from rest_framework.exceptions import ValidationError
from .models import Order, OrderEvent

ALLOWED_TRANSITIONS = {
    Order.Status.DRAFT: {Order.Status.CLIENT_CONFIRMED, Order.Status.CANCELLED},
    Order.Status.CLIENT_CONFIRMED: {
        Order.Status.CUSTOMER_OFFICER_RECEIVED,
        Order.Status.CANCELLED,
    },
    Order.Status.CUSTOMER_OFFICER_RECEIVED: {
        Order.Status.CONTROLLED,
        Order.Status.REJECTED,
        Order.Status.CANCELLED,
    },
    Order.Status.CONTROLLED: {
        Order.Status.APPROVED,
        Order.Status.REJECTED,
        Order.Status.CANCELLED,
    },
    Order.Status.APPROVED: {
        Order.Status.ROUTED_TO_TRADER,
        Order.Status.CANCELLED,
    },
    Order.Status.ROUTED_TO_TRADER: {
        Order.Status.PARTIALLY_FILLED,
        Order.Status.FILLED,
        Order.Status.REJECTED,
        Order.Status.CANCELLED,
    },
    Order.Status.PARTIALLY_FILLED: {
        Order.Status.PARTIALLY_FILLED,
        Order.Status.FILLED,
        Order.Status.CANCELLED,
    },
}

@transaction.atomic
def transition_order(*, order, new_status, actor, comment="", payload=None):
    if new_status not in ALLOWED_TRANSITIONS.get(order.status, set()):
        raise ValidationError(
            f"Transition interdite : {order.status} -> {new_status}."
        )

    previous = order.status
    order.status = new_status
    order.save(update_fields=["status", "updated_at"])

    return OrderEvent.objects.create(
        institution=order.institution,
        order=order,
        event_type="STATUS_CHANGED",
        previous_status=previous,
        new_status=new_status,
        actor=actor,
        comment=comment,
        payload=payload or {},
    )
