from django.conf import settings
from django.db import models
from apps.core.models import InstitutionOwnedModel

class Order(InstitutionOwnedModel):
    class Side(models.TextChoices):
        BUY = "BUY", "Achat"
        SELL = "SELL", "Vente"

    class Status(models.TextChoices):
        DRAFT = "DRAFT", "Brouillon"
        CLIENT_CONFIRMED = "CLIENT_CONFIRMED", "Confirmé client"
        CUSTOMER_OFFICER_RECEIVED = "CUSTOMER_OFFICER_RECEIVED", "Reçu chargé clientèle"
        CONTROLLED = "CONTROLLED", "Contrôlé"
        APPROVED = "APPROVED", "Validé"
        ROUTED_TO_TRADER = "ROUTED_TO_TRADER", "Transmis négociateur"
        PARTIALLY_FILLED = "PARTIALLY_FILLED", "Partiellement exécuté"
        FILLED = "FILLED", "Exécuté"
        REJECTED = "REJECTED", "Rejeté"
        CANCELLED = "CANCELLED", "Annulé"

    class Source(models.TextChoices):
        TICKET = "TICKET", "Ticket"
        CHAT_INVEST = "CHAT_INVEST", "Chat Invest"
        GROUPED = "GROUPED", "Ordre groupé"
        COMMITTEE = "COMMITTEE", "Comité"
        API = "API", "API"

    portfolio = models.ForeignKey("portfolios.Portfolio", on_delete=models.PROTECT, related_name="orders")
    instrument = models.ForeignKey("instruments.Instrument", on_delete=models.PROTECT)
    side = models.CharField(max_length=8, choices=Side.choices)
    quantity = models.DecimalField(max_digits=28, decimal_places=8)
    order_type = models.CharField(max_length=32, default="LIMIT")
    limit_price = models.DecimalField(max_digits=28, decimal_places=8, null=True, blank=True)
    currency = models.CharField(max_length=8)
    source = models.CharField(max_length=24, choices=Source.choices, default=Source.TICKET)
    status = models.CharField(max_length=40, choices=Status.choices, default=Status.DRAFT)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="orders_created")
    customer_officer = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True, blank=True, related_name="orders_as_customer_officer"
    )
    trader = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True, blank=True, related_name="orders_as_trader"
    )
    external_reference = models.CharField(max_length=160, blank=True)
    instructions = models.JSONField(default=dict, blank=True)

    class Meta:
        indexes = [
            models.Index(fields=["institution", "portfolio", "status"]),
            models.Index(fields=["institution", "trader", "status"]),
        ]

class OrderEvent(InstitutionOwnedModel):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="events")
    event_type = models.CharField(max_length=48)
    previous_status = models.CharField(max_length=40, blank=True)
    new_status = models.CharField(max_length=40, blank=True)
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    comment = models.TextField(blank=True)
    payload = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ["created_at"]

class Execution(InstitutionOwnedModel):
    order = models.ForeignKey(Order, on_delete=models.PROTECT, related_name="executions")
    quantity = models.DecimalField(max_digits=28, decimal_places=8)
    price = models.DecimalField(max_digits=28, decimal_places=8)
    currency = models.CharField(max_length=8)
    executed_at = models.DateTimeField()
    venue = models.CharField(max_length=64, blank=True)
    broker_reference = models.CharField(max_length=160, blank=True)
    trader = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)

class Allocation(InstitutionOwnedModel):
    execution = models.ForeignKey(Execution, on_delete=models.PROTECT, related_name="allocations")
    portfolio = models.ForeignKey("portfolios.Portfolio", on_delete=models.PROTECT)
    quantity = models.DecimalField(max_digits=28, decimal_places=8)
    amount = models.DecimalField(max_digits=28, decimal_places=4)
    currency = models.CharField(max_length=8)
