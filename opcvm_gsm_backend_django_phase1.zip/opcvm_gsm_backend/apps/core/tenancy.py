from rest_framework.exceptions import PermissionDenied

def resolve_request_institution(request):
    institution_id = request.META.get("HTTP_X_INSTITUTION_ID")
    memberships = request.user.memberships.filter(is_active=True).select_related("institution")

    if institution_id:
        membership = memberships.filter(institution_id=institution_id).first()
        if not membership:
            raise PermissionDenied("Vous n'appartenez pas à cette SGI.")
        return membership.institution

    membership = memberships.first()
    if not membership:
        raise PermissionDenied("Aucune SGI active associée à cet utilisateur.")
    return membership.institution
