from rest_framework.viewsets import ModelViewSet
from .tenancy import resolve_request_institution

class InstitutionScopedViewSet(ModelViewSet):
    institution_field = "institution"

    def get_institution(self):
        if not hasattr(self, "_institution_cache"):
            self._institution_cache = resolve_request_institution(self.request)
        return self._institution_cache

    def get_queryset(self):
        return super().get_queryset().filter(
            **{self.institution_field: self.get_institution()}
        )

    def perform_create(self, serializer):
        serializer.save(**{self.institution_field: self.get_institution()})
