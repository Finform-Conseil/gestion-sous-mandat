from django.conf import settings
from django.db import models
from apps.core.models import InstitutionOwnedModel

class SecurityMovement(InstitutionOwnedModel):
    class MovementType(models.TextChoices):
        BUY = "BUY", "Achat"
        SELL = "SELL", "Vente"
        TRANSFER_IN = "TRANSFER_IN", "Transfert entrant"
        TRANSFER_OUT = "TRANSFER_OUT", "Transfert sortant"
        SUBSCRIPTION = "SUBSCRIPTION", "Souscription"
        REDEMPTION = "REDEMPTION", "Rachat"
        CORPORATE_ACTION = "CORPORATE_ACTION", "Opération sur titre"
        OTHER = "OTHER", "Autre"

    portfolio = models.ForeignKey("portfolios.Portfolio", on_delete=models.PROTECT, related_name="security_movements")
    securities_account = models.ForeignKey("portfolios.SecuritiesAccount", on_delete=models.PROTECT, related_name="movements")
    instrument = models.ForeignKey("instruments.Instrument", on_delete=models.PROTECT)
    movement_type = models.CharField(max_length=32, choices=MovementType.choices)
    trade_date = models.DateField()
    settlement_date = models.DateField(null=True, blank=True)
    quantity = models.DecimalField(max_digits=28, decimal_places=8)
    unit_price = models.DecimalField(max_digits=28, decimal_places=8, null=True, blank=True)
    currency = models.CharField(max_length=8)
    gross_amount = models.DecimalField(max_digits=28, decimal_places=4, default=0)
    fees = models.DecimalField(max_digits=28, decimal_places=4, default=0)
    taxes = models.DecimalField(max_digits=28, decimal_places=4, default=0)
    net_amount = models.DecimalField(max_digits=28, decimal_places=4, default=0)
    source_system = models.CharField(max_length=64, default="GSM")
    external_reference = models.CharField(max_length=160)
    metadata = models.JSONField(default=dict, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["institution", "source_system", "external_reference"],
                name="uq_security_movement_external_ref",
            )
        ]
        indexes = [
            models.Index(fields=["institution", "portfolio", "trade_date"]),
            models.Index(fields=["institution", "instrument", "trade_date"]),
        ]

class CashMovement(InstitutionOwnedModel):
    portfolio = models.ForeignKey("portfolios.Portfolio", on_delete=models.PROTECT, related_name="cash_movements")
    cash_account = models.ForeignKey("portfolios.CashAccount", on_delete=models.PROTECT, related_name="movements")
    movement_type = models.CharField(max_length=32)
    value_date = models.DateField()
    currency = models.CharField(max_length=8)
    amount = models.DecimalField(max_digits=28, decimal_places=4)
    source_system = models.CharField(max_length=64, default="GSM")
    external_reference = models.CharField(max_length=160)
    related_instrument = models.ForeignKey(
        "instruments.Instrument", on_delete=models.PROTECT, null=True, blank=True
    )
    metadata = models.JSONField(default=dict, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["institution", "source_system", "external_reference"],
                name="uq_cash_movement_external_ref",
            )
        ]
        indexes = [
            models.Index(fields=["institution", "portfolio", "value_date"]),
        ]

class PositionSnapshot(InstitutionOwnedModel):
    portfolio = models.ForeignKey("portfolios.Portfolio", on_delete=models.CASCADE, related_name="position_snapshots")
    instrument = models.ForeignKey("instruments.Instrument", on_delete=models.PROTECT)
    as_of = models.DateField()
    quantity = models.DecimalField(max_digits=28, decimal_places=8)
    available_quantity = models.DecimalField(max_digits=28, decimal_places=8, default=0)
    blocked_quantity = models.DecimalField(max_digits=28, decimal_places=8, default=0)
    average_cost = models.DecimalField(max_digits=28, decimal_places=8, default=0)
    market_price = models.DecimalField(max_digits=28, decimal_places=8, default=0)
    market_value = models.DecimalField(max_digits=28, decimal_places=4, default=0)
    accrued_income = models.DecimalField(max_digits=28, decimal_places=4, default=0)
    currency = models.CharField(max_length=8)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["institution", "portfolio", "instrument", "as_of"],
                name="uq_position_snapshot",
            )
        ]

class CashBalanceSnapshot(InstitutionOwnedModel):
    portfolio = models.ForeignKey("portfolios.Portfolio", on_delete=models.CASCADE, related_name="cash_snapshots")
    cash_account = models.ForeignKey("portfolios.CashAccount", on_delete=models.PROTECT)
    as_of = models.DateField()
    available = models.DecimalField(max_digits=28, decimal_places=4, default=0)
    reserved = models.DecimalField(max_digits=28, decimal_places=4, default=0)
    total = models.DecimalField(max_digits=28, decimal_places=4, default=0)
    currency = models.CharField(max_length=8)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["institution", "cash_account", "as_of"],
                name="uq_cash_balance_snapshot",
            )
        ]

class ValuationSnapshot(InstitutionOwnedModel):
    portfolio = models.ForeignKey("portfolios.Portfolio", on_delete=models.CASCADE, related_name="valuations")
    as_of = models.DateField()
    securities_value = models.DecimalField(max_digits=28, decimal_places=4, default=0)
    cash_value = models.DecimalField(max_digits=28, decimal_places=4, default=0)
    accrued_income = models.DecimalField(max_digits=28, decimal_places=4, default=0)
    total_value = models.DecimalField(max_digits=28, decimal_places=4)
    external_flow_net = models.DecimalField(max_digits=28, decimal_places=4, default=0)
    daily_return = models.DecimalField(max_digits=12, decimal_places=6, null=True, blank=True)
    ytd_return = models.DecimalField(max_digits=12, decimal_places=6, null=True, blank=True)
    currency = models.CharField(max_length=8)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["institution", "portfolio", "as_of"],
                name="uq_valuation_snapshot",
            )
        ]

class ForecastCashflow(InstitutionOwnedModel):
    portfolio = models.ForeignKey("portfolios.Portfolio", on_delete=models.CASCADE, related_name="forecast_cashflows")
    instrument = models.ForeignKey("instruments.Instrument", on_delete=models.PROTECT, null=True, blank=True)
    due_date = models.DateField()
    flow_type = models.CharField(max_length=32)
    gross_amount = models.DecimalField(max_digits=28, decimal_places=4, default=0)
    taxes = models.DecimalField(max_digits=28, decimal_places=4, default=0)
    net_amount = models.DecimalField(max_digits=28, decimal_places=4)
    currency = models.CharField(max_length=8)
    certainty = models.CharField(max_length=24, default="CONFIRMED")
    status = models.CharField(max_length=24, default="EXPECTED")

class WithdrawalRequest(InstitutionOwnedModel):
    portfolio = models.ForeignKey("portfolios.Portfolio", on_delete=models.PROTECT, related_name="withdrawal_requests")
    requested_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    amount = models.DecimalField(max_digits=28, decimal_places=4)
    currency = models.CharField(max_length=8)
    requested_date = models.DateField()
    target_date = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=32, default="REQUESTED")
    reason = models.TextField(blank=True)
