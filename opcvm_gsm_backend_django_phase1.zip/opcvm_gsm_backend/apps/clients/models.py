from django.db import models
from apps.core.models import InstitutionOwnedModel

class Client(InstitutionOwnedModel):
    class ClientType(models.TextChoices):
        INDIVIDUAL = "INDIVIDUAL", "Particulier"
        INSTITUTIONAL = "INSTITUTIONAL", "Institutionnel"

    external_id = models.CharField(max_length=80)
    client_type = models.CharField(max_length=20, choices=ClientType.choices)
    display_name = models.CharField(max_length=255)
    legal_name = models.CharField(max_length=255, blank=True)
    country = models.CharField(max_length=80)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=32, blank=True)
    status = models.CharField(max_length=32, default="ACTIVE")

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["institution", "external_id"],
                name="uq_client_institution_external_id",
            )
        ]
        indexes = [
            models.Index(fields=["institution", "display_name"]),
            models.Index(fields=["institution", "status"]),
        ]

class KYCRecord(InstitutionOwnedModel):
    client = models.OneToOneField(Client, on_delete=models.CASCADE, related_name="kyc")
    status = models.CharField(max_length=32, default="PENDING")
    risk_level = models.CharField(max_length=32, blank=True)
    reviewed_at = models.DateTimeField(null=True, blank=True)
    expires_at = models.DateTimeField(null=True, blank=True)
    payload = models.JSONField(default=dict, blank=True)

class Mandate(InstitutionOwnedModel):
    class MandateType(models.TextChoices):
        DISCRETIONARY = "DISCRETIONARY", "Gestion sous mandat"
        ADVISORY = "ADVISORY", "Gestion conseillée"
        FREE = "FREE", "Gestion libre"

    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name="mandates")
    mandate_type = models.CharField(max_length=24, choices=MandateType.choices)
    reference = models.CharField(max_length=80)
    start_date = models.DateField()
    end_date = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=24, default="ACTIVE")
    constraints = models.JSONField(default=dict, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["institution", "reference"],
                name="uq_mandate_institution_reference",
            )
        ]
