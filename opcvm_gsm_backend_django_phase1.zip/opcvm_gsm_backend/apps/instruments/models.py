from django.db import models
from apps.core.models import UUIDModel, TimeStampedModel

class Exchange(UUIDModel, TimeStampedModel):
    code = models.CharField(max_length=24, unique=True)
    name = models.CharField(max_length=255)
    country = models.CharField(max_length=80, blank=True)
    currency = models.CharField(max_length=8)

class Issuer(UUIDModel, TimeStampedModel):
    name = models.CharField(max_length=255)
    country = models.CharField(max_length=80, blank=True)
    sector = models.CharField(max_length=120, blank=True)

class Instrument(UUIDModel, TimeStampedModel):
    class AssetClass(models.TextChoices):
        LISTED_EQUITY = "LISTED_EQUITY", "Actions cotées"
        UNLISTED_EQUITY = "UNLISTED_EQUITY", "Actions non cotées"
        LISTED_BOND = "LISTED_BOND", "Obligations cotées"
        UNLISTED_BOND = "UNLISTED_BOND", "Obligations non cotées"
        FCP = "FCP", "FCP"
        FCTC = "FCTC", "FCTC"
        REAL_ESTATE = "REAL_ESTATE", "Immobilier"
        CASH = "CASH", "Liquidité"

    symbol = models.CharField(max_length=64)
    name = models.CharField(max_length=255)
    isin = models.CharField(max_length=32, blank=True, db_index=True)
    asset_class = models.CharField(max_length=32, choices=AssetClass.choices)
    exchange = models.ForeignKey(Exchange, on_delete=models.PROTECT, null=True, blank=True, related_name="instruments")
    issuer = models.ForeignKey(Issuer, on_delete=models.PROTECT, null=True, blank=True, related_name="instruments")
    currency = models.CharField(max_length=8)
    is_active = models.BooleanField(default=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["exchange", "symbol"], name="uq_instrument_exchange_symbol")
        ]
