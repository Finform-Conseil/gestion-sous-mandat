from rest_framework import serializers

from apps.institutions.models import Institution, InstitutionMembership
from apps.clients.models import Client, KYCRecord, Mandate
from apps.portfolios.models import Portfolio, PortfolioAssignment, SecuritiesAccount, CashAccount
from apps.instruments.models import Exchange, Issuer, Instrument
from apps.ledger.models import (
    SecurityMovement, CashMovement, PositionSnapshot, CashBalanceSnapshot,
    ValuationSnapshot, ForecastCashflow, WithdrawalRequest,
)
from apps.orders.models import Order, OrderEvent, Execution, Allocation
from apps.committees.models import (
    CommitteeSession, CommitteeDecision, DecisionTarget,
    DecisionExecution, DecisionDeviation,
)
from apps.imports.models import ImportJob, ImportStagingRow
from apps.marketdata.models import MarketIndex, IndexLevel, MarketPrice, FXRate


class InstitutionOwnedSerializer(serializers.ModelSerializer):
    def get_fields(self):
        fields = super().get_fields()
        if "institution" in fields:
            fields["institution"].read_only = True
        return fields


def tenant_serializer(name, model):
    meta = type("Meta", (), {"model": model, "fields": "__all__"})
    return type(name, (InstitutionOwnedSerializer,), {"Meta": meta})


def plain_serializer(name, model):
    meta = type("Meta", (), {"model": model, "fields": "__all__"})
    return type(name, (serializers.ModelSerializer,), {"Meta": meta})


InstitutionSerializer = plain_serializer("InstitutionSerializer", Institution)
MembershipSerializer = tenant_serializer("MembershipSerializer", InstitutionMembership)

ClientSerializer = tenant_serializer("ClientSerializer", Client)
KYCRecordSerializer = tenant_serializer("KYCRecordSerializer", KYCRecord)
MandateSerializer = tenant_serializer("MandateSerializer", Mandate)

PortfolioSerializer = tenant_serializer("PortfolioSerializer", Portfolio)
PortfolioAssignmentSerializer = tenant_serializer("PortfolioAssignmentSerializer", PortfolioAssignment)
SecuritiesAccountSerializer = tenant_serializer("SecuritiesAccountSerializer", SecuritiesAccount)
CashAccountSerializer = tenant_serializer("CashAccountSerializer", CashAccount)

ExchangeSerializer = plain_serializer("ExchangeSerializer", Exchange)
IssuerSerializer = plain_serializer("IssuerSerializer", Issuer)
InstrumentSerializer = plain_serializer("InstrumentSerializer", Instrument)

SecurityMovementSerializer = tenant_serializer("SecurityMovementSerializer", SecurityMovement)
CashMovementSerializer = tenant_serializer("CashMovementSerializer", CashMovement)
PositionSnapshotSerializer = tenant_serializer("PositionSnapshotSerializer", PositionSnapshot)
CashBalanceSnapshotSerializer = tenant_serializer("CashBalanceSnapshotSerializer", CashBalanceSnapshot)
ValuationSnapshotSerializer = tenant_serializer("ValuationSnapshotSerializer", ValuationSnapshot)
ForecastCashflowSerializer = tenant_serializer("ForecastCashflowSerializer", ForecastCashflow)
WithdrawalRequestSerializer = tenant_serializer("WithdrawalRequestSerializer", WithdrawalRequest)

OrderSerializer = tenant_serializer("OrderSerializer", Order)
OrderEventSerializer = tenant_serializer("OrderEventSerializer", OrderEvent)
ExecutionSerializer = tenant_serializer("ExecutionSerializer", Execution)
AllocationSerializer = tenant_serializer("AllocationSerializer", Allocation)

CommitteeSessionSerializer = tenant_serializer("CommitteeSessionSerializer", CommitteeSession)
CommitteeDecisionSerializer = tenant_serializer("CommitteeDecisionSerializer", CommitteeDecision)
DecisionTargetSerializer = tenant_serializer("DecisionTargetSerializer", DecisionTarget)
DecisionExecutionSerializer = tenant_serializer("DecisionExecutionSerializer", DecisionExecution)
DecisionDeviationSerializer = tenant_serializer("DecisionDeviationSerializer", DecisionDeviation)

ImportJobSerializer = tenant_serializer("ImportJobSerializer", ImportJob)
ImportStagingRowSerializer = tenant_serializer("ImportStagingRowSerializer", ImportStagingRow)

MarketIndexSerializer = plain_serializer("MarketIndexSerializer", MarketIndex)
IndexLevelSerializer = plain_serializer("IndexLevelSerializer", IndexLevel)
MarketPriceSerializer = plain_serializer("MarketPriceSerializer", MarketPrice)
FXRateSerializer = plain_serializer("FXRateSerializer", FXRate)


class OrderTransitionSerializer(serializers.Serializer):
    status = serializers.ChoiceField(choices=Order.Status.choices)
    comment = serializers.CharField(required=False, allow_blank=True)
    payload = serializers.JSONField(required=False)


class ImportUploadSerializer(serializers.Serializer):
    file = serializers.FileField()
