from collections import defaultdict
from decimal import Decimal

from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.core.tenancy import resolve_request_institution
from apps.portfolios.models import Portfolio
from apps.ledger.models import PositionSnapshot, CashBalanceSnapshot, ValuationSnapshot
from apps.committees.models import CommitteeSession


ASSET_LABELS = {
    "LISTED_EQUITY": "Actions cotées",
    "UNLISTED_EQUITY": "Actions non cotées",
    "LISTED_BOND": "Obligations cotées",
    "UNLISTED_BOND": "Obligations non cotées",
    "FCP": "FCP",
    "FCTC": "FCTC",
    "REAL_ESTATE": "Immobilier",
    "CASH": "Liquidité",
}

ALLOC_LABELS = {
    "LISTED_EQUITY": "Actions",
    "UNLISTED_EQUITY": "Actions",
    "LISTED_BOND": "Obl. souveraines",
    "UNLISTED_BOND": "Obl. privées",
    "FCP": "Autres",
    "FCTC": "Autres",
    "REAL_ESTATE": "Autres",
}


def latest_valuation(portfolio):
    return portfolio.valuations.order_by("-as_of").first()


def latest_positions(portfolio):
    last_date = (
        portfolio.position_snapshots.order_by("-as_of")
        .values_list("as_of", flat=True)
        .first()
    )
    if not last_date:
        return []
    return list(
        portfolio.position_snapshots.filter(as_of=last_date)
        .select_related("instrument", "instrument__exchange")
    )


def latest_cash(portfolio):
    last_date = (
        portfolio.cash_snapshots.order_by("-as_of")
        .values_list("as_of", flat=True)
        .first()
    )
    if not last_date:
        return []
    return list(portfolio.cash_snapshots.filter(as_of=last_date))


def serialize_free_portfolio(portfolio):
    valuation = latest_valuation(portfolio)
    positions = latest_positions(portfolio)
    cash = latest_cash(portfolio)
    securities_account = portfolio.securities_accounts.order_by("created_at").first()

    return {
        "id": str(portfolio.id),
        "titulaire": portfolio.client.display_name,
        "nom": portfolio.name,
        "sgi": (
            securities_account.custodian_name
            if securities_account and securities_account.custodian_name
            else portfolio.institution.legal_name
        ),
        "pays": portfolio.client.country,
        "marche": securities_account.market if securities_account else "",
        "devise": portfolio.base_currency,
        "numeroCompte": securities_account.account_number if securities_account else "",
        "compteEspeces": float(sum((c.total for c in cash), Decimal("0"))),
        "perfYtd": float(valuation.ytd_return) if valuation and valuation.ytd_return is not None else 0,
        "dateSituation": valuation.as_of.isoformat() if valuation else None,
        "sourceImport": "API Django",
        "lignes": [
            {
                "instrument": p.instrument.name,
                "qte": float(p.quantity),
                "qteDisponible": float(p.available_quantity),
                "qteBloquee": float(p.blocked_quantity),
                "pru": float(p.average_cost),
                "prixActuel": float(p.market_price),
                "classeActif": ASSET_LABELS.get(p.instrument.asset_class, p.instrument.asset_class),
                "deviseOrigine": p.currency,
                "isin": p.instrument.isin,
            }
            for p in positions
        ],
    }


def serialize_managed_client(portfolio):
    valuation = latest_valuation(portfolio)
    positions = latest_positions(portfolio)
    cash_rows = latest_cash(portfolio)
    total = Decimal(str(valuation.total_value if valuation else 0))
    alloc_amounts = defaultdict(lambda: Decimal("0"))

    for p in positions:
        label = ALLOC_LABELS.get(p.instrument.asset_class, "Autres")
        alloc_amounts[label] += p.market_value

    cash_total = sum((c.total for c in cash_rows), Decimal("0"))
    alloc_amounts["Liquidité"] += cash_total

    alloc = {}
    if total > 0:
        for label, amount in alloc_amounts.items():
            alloc[label] = round(float((amount / total) * Decimal("100")), 2)

    sec = portfolio.securities_accounts.order_by("created_at").first()
    client_type = (
        "Institutionnel"
        if portfolio.client.client_type == "INSTITUTIONAL"
        else "Privé"
    )

    return {
        "id": str(portfolio.id),
        "pays": portfolio.client.country,
        "dateEntree": (
            portfolio.mandate.start_date.isoformat()
            if portfolio.mandate and portfolio.mandate.start_date
            else ""
        ),
        "nom": portfolio.client.display_name,
        "type": client_type,
        "marche": sec.market if sec else "",
        "devise": portfolio.base_currency,
        "encours": float(total),
        "perf": float(valuation.ytd_return) if valuation and valuation.ytd_return is not None else 0,
        "risque": portfolio.risk_profile or "Modéré",
        "alertes": 0,
        "profilRisque": portfolio.risk_profile or "Équilibré",
        "rentabilite": float(valuation.ytd_return) if valuation and valuation.ytd_return is not None else 0,
        "alloc": alloc,
        "cible": alloc.copy(),
    }


def serialize_committee_session(session):
    allocations = []
    portfolio_names = set()

    for decision in session.decisions.select_related("instrument").prefetch_related("targets__portfolio"):
        targets = list(decision.targets.select_related("portfolio", "portfolio__client"))
        eligible_names = [t.portfolio.client.display_name for t in targets]
        portfolio_names.update(eligible_names)

        allocations.append({
            "id": str(decision.id),
            "typeInstrument": (
                "Actions"
                if "EQUITY" in decision.instrument.asset_class
                else "Obl. souveraines"
            ),
            "sens": "Achat" if decision.side == "BUY" else "Vente",
            "pourcentageOperation": float(decision.allocation_percentage or 0),
            "marche": decision.market or "Tous",
            "typePortefeuille": decision.portfolio_type or "Tous",
            "instrument": decision.instrument.name,
            "operateur": "<",
            "seuil": 100,
            "typeOrdre": (
                "Ordre à cours limité"
                if decision.order_type == "LIMIT"
                else "Ordre au marché"
            ),
            "prixMin": float(decision.min_price) if decision.min_price is not None else "",
            "prixMax": float(decision.max_price) if decision.max_price is not None else "",
            "prixObjectif": float(decision.target_price) if decision.target_price is not None else "",
            "portefeuillesEligibles": eligible_names,
            "rationale": decision.rationale,
        })

    return {
        "id": str(session.id),
        "creeLe": session.meeting_date.isoformat(),
        "libelleDate": session.meeting_date.strftime("%d/%m/%Y %H:%M"),
        "nombrePortefeuilles": len(portfolio_names),
        "sourceApi": "Django",
        "allocations": allocations,
    }


class CompatibilityBootstrapView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        institution = resolve_request_institution(request)

        free_portfolios = (
            Portfolio.objects.filter(
                institution=institution,
                management_mode=Portfolio.ManagementMode.FREE,
                status="ACTIVE",
            )
            .select_related("client", "mandate", "institution")
            .prefetch_related(
                "securities_accounts",
                "position_snapshots__instrument__exchange",
                "cash_snapshots",
                "valuations",
            )
        )

        managed_portfolios = (
            Portfolio.objects.filter(
                institution=institution,
                management_mode=Portfolio.ManagementMode.MANDATED,
                status="ACTIVE",
            )
            .select_related("client", "mandate", "institution")
            .prefetch_related(
                "securities_accounts",
                "position_snapshots__instrument__exchange",
                "cash_snapshots",
                "valuations",
            )
        )

        sessions = (
            CommitteeSession.objects.filter(institution=institution)
            .select_related("chairman")
            .prefetch_related(
                "decisions__instrument",
                "decisions__targets__portfolio__client",
            )
            .order_by("-meeting_date")[:10]
        )

        return Response({
            "institution": {
                "id": str(institution.id),
                "code": institution.code,
                "name": institution.legal_name,
                "baseCurrency": institution.base_currency,
            },
            "freePortfolios": [
                serialize_free_portfolio(p) for p in free_portfolios
            ],
            "managedClients": [
                serialize_managed_client(p) for p in managed_portfolios
            ],
            "committeeDecisions": [
                serialize_committee_session(s) for s in sessions
                if s.decisions.exists()
            ],
        })
