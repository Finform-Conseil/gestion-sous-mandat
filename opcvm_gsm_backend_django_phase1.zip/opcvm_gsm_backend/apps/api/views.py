from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.viewsets import ReadOnlyModelViewSet

from apps.core.viewsets import InstitutionScopedViewSet
from apps.institutions.models import Institution, InstitutionMembership
from apps.clients.models import Client, KYCRecord, Mandate
from apps.portfolios.models import Portfolio, PortfolioAssignment, SecuritiesAccount, CashAccount
from apps.instruments.models import Exchange, Issuer, Instrument
from apps.ledger.models import (
    SecurityMovement, CashMovement, PositionSnapshot, CashBalanceSnapshot,
    ValuationSnapshot, ForecastCashflow, WithdrawalRequest,
)
from apps.orders.models import Order, OrderEvent, Execution, Allocation
from apps.orders.services import transition_order
from apps.committees.models import (
    CommitteeSession, CommitteeDecision, DecisionTarget,
    DecisionExecution, DecisionDeviation,
)
from apps.imports.models import ImportJob, ImportStagingRow
from apps.imports.services import create_import_job
from apps.marketdata.models import MarketIndex, IndexLevel, MarketPrice, FXRate

from .serializers import *


class InstitutionViewSet(ReadOnlyModelViewSet):
    serializer_class = InstitutionSerializer

    def get_queryset(self):
        return Institution.objects.filter(
            memberships__user=self.request.user,
            memberships__is_active=True,
            is_active=True,
        ).distinct()


class MembershipViewSet(InstitutionScopedViewSet):
    queryset = InstitutionMembership.objects.select_related("institution", "user")
    serializer_class = MembershipSerializer
    filterset_fields = ["role", "is_active"]


class ClientViewSet(InstitutionScopedViewSet):
    queryset = Client.objects.all()
    serializer_class = ClientSerializer
    filterset_fields = ["client_type", "country", "status"]
    search_fields = ["display_name", "legal_name", "external_id"]


class KYCRecordViewSet(InstitutionScopedViewSet):
    queryset = KYCRecord.objects.select_related("client")
    serializer_class = KYCRecordSerializer
    filterset_fields = ["status", "risk_level", "client"]


class MandateViewSet(InstitutionScopedViewSet):
    queryset = Mandate.objects.select_related("client")
    serializer_class = MandateSerializer
    filterset_fields = ["client", "mandate_type", "status"]


class PortfolioViewSet(InstitutionScopedViewSet):
    queryset = Portfolio.objects.select_related("client", "mandate")
    serializer_class = PortfolioSerializer
    filterset_fields = ["client", "management_mode", "base_currency", "status"]
    search_fields = ["code", "name", "client__display_name"]


class PortfolioAssignmentViewSet(InstitutionScopedViewSet):
    queryset = PortfolioAssignment.objects.select_related("portfolio", "user")
    serializer_class = PortfolioAssignmentSerializer
    filterset_fields = ["portfolio", "user", "role", "is_primary"]


class SecuritiesAccountViewSet(InstitutionScopedViewSet):
    queryset = SecuritiesAccount.objects.select_related("portfolio", "custodian_institution")
    serializer_class = SecuritiesAccountSerializer
    filterset_fields = ["portfolio", "market", "currency", "is_external"]


class CashAccountViewSet(InstitutionScopedViewSet):
    queryset = CashAccount.objects.select_related("portfolio")
    serializer_class = CashAccountSerializer
    filterset_fields = ["portfolio", "currency", "is_primary"]


class ExchangeViewSet(ReadOnlyModelViewSet):
    queryset = Exchange.objects.all().order_by("code")
    serializer_class = ExchangeSerializer


class IssuerViewSet(ReadOnlyModelViewSet):
    queryset = Issuer.objects.all().order_by("name")
    serializer_class = IssuerSerializer
    search_fields = ["name", "country", "sector"]


class InstrumentViewSet(ReadOnlyModelViewSet):
    queryset = Instrument.objects.select_related("exchange", "issuer")
    serializer_class = InstrumentSerializer
    filterset_fields = ["asset_class", "exchange", "currency", "is_active"]
    search_fields = ["symbol", "name", "isin"]


class SecurityMovementViewSet(InstitutionScopedViewSet):
    queryset = SecurityMovement.objects.select_related(
        "portfolio", "instrument", "securities_account"
    )
    serializer_class = SecurityMovementSerializer
    filterset_fields = ["portfolio", "instrument", "movement_type", "trade_date", "currency"]


class CashMovementViewSet(InstitutionScopedViewSet):
    queryset = CashMovement.objects.select_related(
        "portfolio", "cash_account", "related_instrument"
    )
    serializer_class = CashMovementSerializer
    filterset_fields = ["portfolio", "movement_type", "value_date", "currency"]


class PositionSnapshotViewSet(InstitutionScopedViewSet):
    queryset = PositionSnapshot.objects.select_related("portfolio", "instrument")
    serializer_class = PositionSnapshotSerializer
    filterset_fields = ["portfolio", "instrument", "as_of", "currency"]


class CashBalanceSnapshotViewSet(InstitutionScopedViewSet):
    queryset = CashBalanceSnapshot.objects.select_related("portfolio", "cash_account")
    serializer_class = CashBalanceSnapshotSerializer
    filterset_fields = ["portfolio", "cash_account", "as_of", "currency"]


class ValuationSnapshotViewSet(InstitutionScopedViewSet):
    queryset = ValuationSnapshot.objects.select_related("portfolio")
    serializer_class = ValuationSnapshotSerializer
    filterset_fields = ["portfolio", "as_of", "currency"]


class ForecastCashflowViewSet(InstitutionScopedViewSet):
    queryset = ForecastCashflow.objects.select_related("portfolio", "instrument")
    serializer_class = ForecastCashflowSerializer
    filterset_fields = ["portfolio", "flow_type", "due_date", "currency", "status"]


class WithdrawalRequestViewSet(InstitutionScopedViewSet):
    queryset = WithdrawalRequest.objects.select_related("portfolio", "requested_by")
    serializer_class = WithdrawalRequestSerializer
    filterset_fields = ["portfolio", "status", "requested_date", "currency"]


class OrderViewSet(InstitutionScopedViewSet):
    queryset = Order.objects.select_related(
        "portfolio", "instrument", "created_by", "customer_officer", "trader"
    )
    serializer_class = OrderSerializer
    filterset_fields = [
        "portfolio", "instrument", "side", "source",
        "status", "trader", "customer_officer",
    ]
    search_fields = ["external_reference"]

    @action(detail=True, methods=["post"])
    def transition(self, request, pk=None):
        order = self.get_object()
        serializer = OrderTransitionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        event = transition_order(
            order=order,
            new_status=serializer.validated_data["status"],
            actor=request.user,
            comment=serializer.validated_data.get("comment", ""),
            payload=serializer.validated_data.get("payload", {}),
        )
        return Response(OrderEventSerializer(event).data)


class OrderEventViewSet(InstitutionScopedViewSet):
    queryset = OrderEvent.objects.select_related("order", "actor")
    serializer_class = OrderEventSerializer
    http_method_names = ["get", "head", "options"]
    filterset_fields = ["order", "event_type", "new_status"]


class ExecutionViewSet(InstitutionScopedViewSet):
    queryset = Execution.objects.select_related("order", "trader")
    serializer_class = ExecutionSerializer
    filterset_fields = ["order", "trader", "executed_at", "venue"]


class AllocationViewSet(InstitutionScopedViewSet):
    queryset = Allocation.objects.select_related("execution", "portfolio")
    serializer_class = AllocationSerializer
    filterset_fields = ["execution", "portfolio", "currency"]


class CommitteeSessionViewSet(InstitutionScopedViewSet):
    queryset = CommitteeSession.objects.select_related("chairman").prefetch_related("participants")
    serializer_class = CommitteeSessionSerializer
    filterset_fields = ["status", "meeting_date"]


class CommitteeDecisionViewSet(InstitutionScopedViewSet):
    queryset = CommitteeDecision.objects.select_related("session", "instrument")
    serializer_class = CommitteeDecisionSerializer
    filterset_fields = ["session", "instrument", "side", "market"]


class DecisionTargetViewSet(InstitutionScopedViewSet):
    queryset = DecisionTarget.objects.select_related("decision", "portfolio")
    serializer_class = DecisionTargetSerializer
    filterset_fields = ["decision", "portfolio", "currency"]


class DecisionExecutionViewSet(InstitutionScopedViewSet):
    queryset = DecisionExecution.objects.select_related(
        "decision", "portfolio", "manager", "order"
    )
    serializer_class = DecisionExecutionSerializer
    filterset_fields = ["decision", "portfolio", "manager"]


class DecisionDeviationViewSet(InstitutionScopedViewSet):
    queryset = DecisionDeviation.objects.select_related(
        "decision", "portfolio", "manager"
    )
    serializer_class = DecisionDeviationSerializer
    filterset_fields = ["decision", "portfolio", "manager", "reason_code"]


class ImportJobViewSet(InstitutionScopedViewSet):
    queryset = ImportJob.objects.select_related("uploaded_by", "portfolio")
    serializer_class = ImportJobSerializer
    filterset_fields = ["status", "source", "portfolio"]

    @action(detail=False, methods=["post"], url_path="upload")
    def upload(self, request):
        serializer = ImportUploadSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        job = create_import_job(
            institution=self.get_institution(),
            user=request.user,
            uploaded_file=serializer.validated_data["file"],
        )
        return Response(ImportJobSerializer(job).data, status=201)

    @action(detail=True, methods=["get"])
    def rows(self, request, pk=None):
        job = self.get_object()
        rows = ImportStagingRow.objects.filter(
            institution=self.get_institution(),
            job=job,
        ).order_by("sheet", "row_number")
        return Response(ImportStagingRowSerializer(rows, many=True).data)


class MarketIndexViewSet(ReadOnlyModelViewSet):
    queryset = MarketIndex.objects.select_related("exchange")
    serializer_class = MarketIndexSerializer
    filterset_fields = ["exchange", "code", "currency", "is_active"]
    search_fields = ["code", "name"]


class IndexLevelViewSet(ReadOnlyModelViewSet):
    queryset = IndexLevel.objects.select_related("index", "index__exchange")
    serializer_class = IndexLevelSerializer
    filterset_fields = ["index", "date", "source"]
    ordering_fields = ["date"]


class MarketPriceViewSet(ReadOnlyModelViewSet):
    queryset = MarketPrice.objects.select_related("instrument")
    serializer_class = MarketPriceSerializer
    filterset_fields = ["instrument", "date", "currency", "source"]
    ordering_fields = ["date"]


class FXRateViewSet(ReadOnlyModelViewSet):
    queryset = FXRate.objects.all()
    serializer_class = FXRateSerializer
    filterset_fields = ["base_currency", "quote_currency", "date", "source"]
    ordering_fields = ["date"]
