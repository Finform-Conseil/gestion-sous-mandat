from django.urls import path
from rest_framework.routers import DefaultRouter
from .views import *
from .compat import CompatibilityBootstrapView

router = DefaultRouter()

router.register("institutions", InstitutionViewSet, basename="institution")
router.register("memberships", MembershipViewSet)

router.register("clients", ClientViewSet)
router.register("kyc-records", KYCRecordViewSet)
router.register("mandates", MandateViewSet)

router.register("portfolios", PortfolioViewSet)
router.register("portfolio-assignments", PortfolioAssignmentViewSet)
router.register("securities-accounts", SecuritiesAccountViewSet)
router.register("cash-accounts", CashAccountViewSet)

router.register("exchanges", ExchangeViewSet)
router.register("issuers", IssuerViewSet)
router.register("instruments", InstrumentViewSet)

router.register("security-movements", SecurityMovementViewSet)
router.register("cash-movements", CashMovementViewSet)
router.register("position-snapshots", PositionSnapshotViewSet)
router.register("cash-balance-snapshots", CashBalanceSnapshotViewSet)
router.register("valuations", ValuationSnapshotViewSet)
router.register("forecast-cashflows", ForecastCashflowViewSet)
router.register("withdrawal-requests", WithdrawalRequestViewSet)

router.register("orders", OrderViewSet)
router.register("order-events", OrderEventViewSet)
router.register("executions", ExecutionViewSet)
router.register("allocations", AllocationViewSet)

router.register("committee-sessions", CommitteeSessionViewSet)
router.register("committee-decisions", CommitteeDecisionViewSet)
router.register("decision-targets", DecisionTargetViewSet)
router.register("decision-executions", DecisionExecutionViewSet)
router.register("decision-deviations", DecisionDeviationViewSet)

router.register("import-jobs", ImportJobViewSet)

router.register("market-indices", MarketIndexViewSet)
router.register("index-levels", IndexLevelViewSet)
router.register("market-prices", MarketPriceViewSet)
router.register("fx-rates", FXRateViewSet)

urlpatterns = [path("compat/bootstrap/", CompatibilityBootstrapView.as_view())] + router.urls
