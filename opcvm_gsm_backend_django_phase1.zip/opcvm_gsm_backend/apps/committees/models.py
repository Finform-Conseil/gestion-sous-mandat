from django.conf import settings
from django.db import models
from apps.core.models import InstitutionOwnedModel

class CommitteeSession(InstitutionOwnedModel):
    meeting_date = models.DateTimeField()
    title = models.CharField(max_length=255)
    status = models.CharField(max_length=16, default="DRAFT")
    chairman = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="committee_sessions_chair"
    )
    participants = models.ManyToManyField(
        settings.AUTH_USER_MODEL, related_name="committee_sessions", blank=True
    )
    minutes_summary = models.TextField(blank=True)
    validated_at = models.DateTimeField(null=True, blank=True)

class CommitteeDecision(InstitutionOwnedModel):
    session = models.ForeignKey(CommitteeSession, on_delete=models.CASCADE, related_name="decisions")
    instrument = models.ForeignKey("instruments.Instrument", on_delete=models.PROTECT)
    side = models.CharField(max_length=8, choices=[("BUY", "Achat"), ("SELL", "Vente")])
    market = models.CharField(max_length=32, blank=True)
    portfolio_type = models.CharField(max_length=32, blank=True)
    allocation_percentage = models.DecimalField(max_digits=9, decimal_places=4, null=True, blank=True)
    min_price = models.DecimalField(max_digits=28, decimal_places=8, null=True, blank=True)
    max_price = models.DecimalField(max_digits=28, decimal_places=8, null=True, blank=True)
    target_price = models.DecimalField(max_digits=28, decimal_places=8, null=True, blank=True)
    order_type = models.CharField(max_length=32, default="LIMIT")
    rationale = models.TextField(blank=True)

class DecisionTarget(InstitutionOwnedModel):
    decision = models.ForeignKey(CommitteeDecision, on_delete=models.CASCADE, related_name="targets")
    portfolio = models.ForeignKey("portfolios.Portfolio", on_delete=models.PROTECT)
    recommended_amount = models.DecimalField(max_digits=28, decimal_places=4, null=True, blank=True)
    recommended_quantity = models.DecimalField(max_digits=28, decimal_places=8, null=True, blank=True)
    currency = models.CharField(max_length=8)

class DecisionExecution(InstitutionOwnedModel):
    decision = models.ForeignKey(CommitteeDecision, on_delete=models.PROTECT, related_name="decision_executions")
    portfolio = models.ForeignKey("portfolios.Portfolio", on_delete=models.PROTECT)
    manager = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    order = models.ForeignKey("orders.Order", on_delete=models.PROTECT, null=True, blank=True)
    executed_amount = models.DecimalField(max_digits=28, decimal_places=4, default=0)
    executed_quantity = models.DecimalField(max_digits=28, decimal_places=8, default=0)
    average_execution_price = models.DecimalField(max_digits=28, decimal_places=8, null=True, blank=True)
    current_mark_price = models.DecimalField(max_digits=28, decimal_places=8, null=True, blank=True)
    result_amount = models.DecimalField(max_digits=28, decimal_places=4, null=True, blank=True)
    result_percentage = models.DecimalField(max_digits=12, decimal_places=6, null=True, blank=True)
    as_of = models.DateTimeField(null=True, blank=True)

class DecisionDeviation(InstitutionOwnedModel):
    class Reason(models.TextChoices):
        CLIENT_WITHDRAWAL = "CLIENT_WITHDRAWAL", "Retrait client"
        INSUFFICIENT_CASH = "INSUFFICIENT_CASH", "Liquidité insuffisante"
        PRICE_OUTSIDE_RANGE = "PRICE_OUTSIDE_RANGE", "Cours hors fourchette"
        PORTFOLIO_LIMIT = "PORTFOLIO_LIMIT", "Limite portefeuille"
        RISK_CONSTRAINT = "RISK_CONSTRAINT", "Contrainte de risque"
        MARKET_LIQUIDITY = "MARKET_LIQUIDITY", "Liquidité marché"
        CLIENT_RESTRICTION = "CLIENT_RESTRICTION", "Restriction client"
        OPERATIONAL = "OPERATIONAL", "Contrainte opérationnelle"
        MANAGER_JUDGEMENT = "MANAGER_JUDGEMENT", "Jugement du gérant"
        OTHER = "OTHER", "Autre"

    decision = models.ForeignKey(CommitteeDecision, on_delete=models.PROTECT, related_name="deviations")
    portfolio = models.ForeignKey("portfolios.Portfolio", on_delete=models.PROTECT)
    manager = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    expected_action = models.JSONField(default=dict)
    actual_action = models.JSONField(default=dict)
    reason_code = models.CharField(max_length=40, choices=Reason.choices)
    reason_comment = models.TextField(blank=True)
