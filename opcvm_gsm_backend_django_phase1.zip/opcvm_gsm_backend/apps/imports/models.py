from django.conf import settings
from django.db import models
from apps.core.models import InstitutionOwnedModel

class ImportJob(InstitutionOwnedModel):
    class Status(models.TextChoices):
        RECEIVED = "RECEIVED", "Reçu"
        PARSING = "PARSING", "Parsing"
        READY = "READY", "Prêt"
        COMMITTED = "COMMITTED", "Intégré"
        FAILED = "FAILED", "Échec"

    source = models.CharField(max_length=32, default="EXCEL_SGI")
    original_filename = models.CharField(max_length=255)
    file = models.FileField(upload_to="imports/%Y/%m/%d/")
    sha256 = models.CharField(max_length=64, db_index=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.RECEIVED)
    uploaded_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    portfolio = models.ForeignKey(
        "portfolios.Portfolio", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="import_jobs"
    )
    summary = models.JSONField(default=dict, blank=True)

class ImportStagingRow(InstitutionOwnedModel):
    job = models.ForeignKey(ImportJob, on_delete=models.CASCADE, related_name="staging_rows")
    sheet = models.CharField(max_length=48)
    row_number = models.PositiveIntegerField()
    raw_data = models.JSONField(default=dict)
    normalized_data = models.JSONField(default=dict, blank=True)
    status = models.CharField(max_length=16, default="RAW")
    messages = models.JSONField(default=list, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["job", "sheet", "row_number"],
                name="uq_import_staging_row",
            )
        ]
