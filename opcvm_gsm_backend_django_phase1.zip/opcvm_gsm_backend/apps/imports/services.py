import hashlib
from openpyxl import load_workbook
from django.db import transaction
from rest_framework.exceptions import ValidationError
from .models import ImportJob, ImportStagingRow

REQUIRED_SHEETS = {"Compte", "Positions", "Mouvements"}
OPTIONAL_SHEETS = {"Ordres_ouverts", "Flux_futurs", "Valorisations"}

def file_sha256(uploaded_file):
    digest = hashlib.sha256()
    for chunk in uploaded_file.chunks():
        digest.update(chunk)
    uploaded_file.seek(0)
    return digest.hexdigest()

@transaction.atomic
def create_import_job(*, institution, user, uploaded_file):
    job = ImportJob.objects.create(
        institution=institution,
        source="EXCEL_SGI",
        original_filename=uploaded_file.name,
        file=uploaded_file,
        sha256=file_sha256(uploaded_file),
        uploaded_by=user,
    )
    return parse_import_job(job)

@transaction.atomic
def parse_import_job(job):
    job.status = ImportJob.Status.PARSING
    job.save(update_fields=["status", "updated_at"])

    workbook = load_workbook(job.file.path, read_only=True, data_only=True)
    missing = REQUIRED_SHEETS.difference(workbook.sheetnames)
    if missing:
        job.status = ImportJob.Status.FAILED
        job.summary = {"missing_sheets": sorted(missing)}
        job.save(update_fields=["status", "summary", "updated_at"])
        raise ValidationError(
            f"Feuilles obligatoires absentes : {', '.join(sorted(missing))}."
        )

    ImportStagingRow.objects.filter(job=job).delete()
    counts = {}

    for sheet_name in [*sorted(REQUIRED_SHEETS), *sorted(OPTIONAL_SHEETS)]:
        if sheet_name not in workbook.sheetnames:
            continue

        ws = workbook[sheet_name]
        rows = ws.iter_rows(values_only=True)
        headers = [str(v).strip() if v is not None else "" for v in next(rows)]
        count = 0

        for row_number, values in enumerate(rows, start=2):
            raw = {
                headers[i]: values[i]
                for i in range(min(len(headers), len(values)))
                if headers[i]
            }
            if not any(value not in (None, "") for value in raw.values()):
                continue

            ImportStagingRow.objects.create(
                institution=job.institution,
                job=job,
                sheet=sheet_name,
                row_number=row_number,
                raw_data=raw,
            )
            count += 1

        counts[sheet_name] = count

    job.status = ImportJob.Status.READY
    job.summary = {
        "rows_by_sheet": counts,
        "optional_sheets_present": sorted(
            OPTIONAL_SHEETS.intersection(workbook.sheetnames)
        ),
    }
    job.save(update_fields=["status", "summary", "updated_at"])
    return job
